import * as functions from "firebase-functions";
import * as admin from "firebase-admin";
import * as express from "express";
import * as cors from "cors";

admin.initializeApp();
const db = admin.firestore();
const app = express();
app.use(cors({ origin: true }));

// CRUD API
app.get("/users", async (req, res) => {
  const snapshot = await db.collection("users").get();
  res.json(snapshot.docs.map((doc) => ({ id: doc.id, ...doc.data() })));
});

app.post("/users", async (req, res) => {
  const user = req.body;
  const docRef = await db.collection("users").add(user);
  res.json({ id: docRef.id, ...user });
});

app.put("/users/:id", async (req, res) => {
  const { id } = req.params;
  await db.collection("users").doc(id).update(req.body);
  res.json({ id, ...req.body });
});

app.delete("/users/:id", async (req, res) => {
  const { id } = req.params;
  await db.collection("users").doc(id).delete();
  res.json({ id });
});

// Export API
exports.api = functions.https.onRequest(app);
