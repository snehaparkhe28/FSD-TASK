# Full-Stack Next.js + Google Cloud Functions Project

## 📜 Setup Instructions

### 🚀 1. Install Dependencies
```bash
cd frontend && npm install
cd ../backend && npm install
```

### 🐳 2. Run with Docker
```bash
docker-compose up --build
```

### 📡 API Endpoints
| Method | Endpoint       | Description         |
|--------|--------------|---------------------|
| GET    | `/users`      | Fetch all users    |
| POST   | `/users`      | Add a new user     |
| PUT    | `/users/:id`  | Update a user      |
| DELETE | `/users/:id`  | Delete a user      |
